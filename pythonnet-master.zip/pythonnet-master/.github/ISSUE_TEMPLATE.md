### Environment

-   Pythonnet version:
-   Python version:
-   Operating System:
-   .NET Runtime:

### Details

-   Describe what you were trying to get done.

    _TODO_

-   What commands did you run to trigger this issue? If you can provide a
    [Minimal, Complete, and Verifiable example](http://stackoverflow.com/help/mcve)
    this will help us understand the issue.

```python
    print('TODO')
```

-   If there was a crash, please include the traceback here.

```python
    print('TODO')
```
