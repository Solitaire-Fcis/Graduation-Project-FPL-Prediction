namespace Python.Runtime.Native;

struct PyInterpreterState
{
}
