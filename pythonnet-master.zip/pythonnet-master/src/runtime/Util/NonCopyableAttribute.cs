namespace Python.Runtime
{
    using  System;
    [AttributeUsage(AttributeTargets.Struct)]
    class NonCopyableAttribute : Attribute { }
}
