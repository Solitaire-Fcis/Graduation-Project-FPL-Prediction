# -*- coding: utf-8 -*-

import sys
# if argv is available, as expected, then no exception
num_args = len(sys.argv)
