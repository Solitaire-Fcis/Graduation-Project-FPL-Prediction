
/// <summary>
/// Supports units tests for access to types without a namespace.
/// </summary>
public class NoNamespaceType
{
}
